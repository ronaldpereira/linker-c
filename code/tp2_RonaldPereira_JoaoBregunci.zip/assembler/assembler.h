#ifndef ASSEMBLER
#define ASSEMBLER
#include <stdio.h>

void assembler(FILE *output, FILE *_main, FILE **library, int numLib);

#endif
