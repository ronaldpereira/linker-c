#ifndef BINARY_CONVERTER
#define BINARY_CONVERTER

bool *binaryConversion(bool *bin, int dec);
bool *binaryTwoComplement(bool *comp, int dec);
void binaryConversion16bits(bool *bin, int dec);
void binaryTwoComplement16bits(bool *comp, int dec);

#endif
