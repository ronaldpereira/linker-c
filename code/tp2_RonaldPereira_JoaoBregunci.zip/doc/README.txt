Esse programa possui alguma regras que DEVEM ser respeitadas ao estruturar um arquivo Assembly para servir de entrada para ele:

1- Não devem haver nenhum espaço (ou tabulação) antes de uma linha que contém somente comentários

2- Não devem haver nenhuma linha escrita no fim do programa (após os .datas), mesmo que sejam comentários

3- Não devem haver nenhum rótulo (label) no meio do programa Assembly que não esteja declarado em outro local do código

4- Labels devem começar com um underline "_", tanto para jumps ou calls
